# Plugin Notification

Whith this plugin, you can: 

* define the fields to show in the notification. It can be do this form elements
* generate the notification (nice design)

These notifications has been tested on many mail clients (software & web).


# Quick How-To
1) Name it with a personal name (use ticket "action" - generated for exemple).
2) Then go to /front/notification.php
3) Click the name you want to change (corresponding to the template you created)
4) click the template tab (second tab)
5) Click the id of the template (not the name)
6) Choose the template name you generated
7) Save

<3 enjoy <3

# Known issues

Editing a template directly in GLPI will broke the template, and you will need to re-generate it.
Edit from database directly if needed.