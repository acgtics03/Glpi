# GLPI plugin Costs

<img src="https://raw.githubusercontent.com/ticgal/costs/multimedia/costs-logo-trans.png" alt="Costs Logo" height="250px" width="250px" class="js-lazy-loaded">

GLPI Plugin Costs. Automatic costs generation.

[![License](https://img.shields.io/badge/License-GNU%20AGPLv3-blue.svg?style=flat-square)](https://gitlab.com/TICgal/gdrive/blob/master/LICENSE)
[![Twitter](https://img.shields.io/badge/Twitter-TICgal-blue.svg?style=flat-square)](https://twitter.com/ticgalcom)
[![Web](https://img.shields.io/badge/Web-TICgal-blue.svg?style=flat-square)](https://tic.gal/)

## English
This plugin allows you to assign both fixed an time (hourly) costs and generates them automatically when solving a ticket.
(Soon) Check out the wiki for setup instructions: https://github.com/ticgal/costs/wiki/

## Galego
Este módulo permite asignar custos fixos e horarios e xera as entradas de xeito automatico cando se resolve a petición.
(Proximamente) Instruccións de configuración na wiki: https://github.com/ticgal/costs/wiki/

## Español
Este módulo permite asignar costes fijos y horarios generando las entradas de manera automatica cuando se resuelve la petición.
(Próximamente)Instrucciones de configuración en la wiki: https://github.com/ticgal/costs/wiki/
